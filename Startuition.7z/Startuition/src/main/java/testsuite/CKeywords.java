package testsuite;

public class CKeywords {
	String keyword;
	String description;
	
	public CKeywords(String keyword, String description) {
		super();
		this.keyword = keyword;
		this.description = description;
	}

	public String getKeyword() {
		return keyword;
	}
	
	public String getDescription() {
		return description;
	}
}
