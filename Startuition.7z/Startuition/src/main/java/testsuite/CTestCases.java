package testsuite;

public class CTestCases {
	private String tcid;
	private String pageobject;
	private String teststep;
	private String keyword;
	private String locatortype;
	private String lcoatorvalue;
	private String parameter;
	private String conditional;
	private String teststepstatus;
	
	public CTestCases(String tcid, String pageobject, String teststep, String keyword, String locatortype,
			String lcoatorvalue, String parameter, String conditional) {
		super();
		this.tcid = tcid;
		this.pageobject = pageobject;
		this.teststep = teststep;
		this.keyword = keyword;
		this.locatortype = locatortype;
		this.lcoatorvalue = lcoatorvalue;
		this.parameter = parameter;
		this.conditional = conditional;
	}
	
	public String getTcid() {
		return tcid;
	}
	public String getPageobject() {
		return pageobject;
	}
	public String getTeststep() {
		return teststep;
	}
	public String getKeyword() {
		return keyword;
	}
	public String getLocatortype() {
		return locatortype;
	}
	public String getLcoatorvalue() {
		return lcoatorvalue;
	}
	public String getParameter() {
		return parameter;
	}
	public String getConditional() {
		return conditional;
	}
	public String getTeststepstatus() {
		return teststepstatus;
	}

	public void setTeststepstatus(String teststepstatus) {
		this.teststepstatus = teststepstatus;
	}
	
}
