package testsuite;

public class CLocators {
	private String locator;
	private String description;
	
	public CLocators(String locator, String description) {
		super();
		this.locator = locator;
		this.description = description;
	}

	public String getLocator() {
		return locator;
	}

	public String getDescription() {
		return description;
	}
}
