package testsuite;

public class CTestSuite {
	private String testcase;
	private String description;
	private boolean runmode;
	private String testresult;
	
	public CTestSuite(String testcase, String description, boolean runmode, String testresult) {
		super();
		this.testcase = testcase;
		this.description = description;
		this.runmode = runmode;
		this.testresult = testresult;
	}
	
	public String getTestcase() {
		return testcase;
	}
	public String getDescription() {
		return description;
	}
	public boolean isRunmode() {
		return runmode;
	}
	public String getTestresult() {
		return testresult;
	}
	
	public void setTestresult(String testResult) {
		this.testresult = testResult;
	}
}
