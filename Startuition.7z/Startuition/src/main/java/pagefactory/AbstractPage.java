package pagefactory;

import org.openqa.selenium.WebDriver;

public abstract class AbstractPage {
	protected WebDriver driver;
	
	public AbstractPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebDriver getDriver() { return driver; }
	
	public HomePage navigateToWebApp() {
		driver.navigate().to("http://www.startuition.org.uk");
		return new HomePage(driver);
	}
}
