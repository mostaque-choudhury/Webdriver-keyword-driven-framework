package pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends AbstractPage {
	
	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	public HomePageMemberLogin fillInMemberLoginData(String locatorType, String locatorValue) {
		switch(locatorType) {
			case "Id" : 
				driver.findElement(By.id(locatorValue)).click();
			break;
			case "XPath" :
				driver.findElement(By.xpath(locatorValue)).click();
			break;
			case "CssSelector" :
				driver.findElement(By.cssSelector(locatorValue)).click();
			break;
		}
		return new HomePageMemberLogin(driver);
	}
	
	

}
