package pagefactory;

import org.openqa.selenium.WebDriver;

public class HomePageMemberLogin extends AbstractPage {

	public HomePageMemberLogin(WebDriver driver) {
		super(driver);
	}
}
