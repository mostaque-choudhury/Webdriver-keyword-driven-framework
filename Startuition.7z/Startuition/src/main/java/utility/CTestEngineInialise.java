package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import testsuite.CKeywords;
import testsuite.CLocators;
import testsuite.CTestCases;
import testsuite.CTestSuite;

public class CTestEngineInialise extends AbstractWebDriver {
	List<CKeywords> keywords;
	List<CLocators> locators;
	Map<String, ArrayList<CTestCases>> testcases;
	List<CTestSuite> testsuites;
	String filename;
	int nNoOfSheets = 0;
	
	public CTestEngineInialise(String filename) {
		super("chrome");
		this.filename = filename;
		try(HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(new File(filename)))) {
			nNoOfSheets = workbook.getNumberOfSheets();
			keywords = new ArrayList<CKeywords>();
			testcases = new HashedMap<String, ArrayList<CTestCases>>();
			testsuites = new ArrayList<CTestSuite>();
			locators = new ArrayList<CLocators>();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// public WebDriver getWebDriver() { return getWebDriver(); }
	
	public void LoadTestEngineToMemory() {
		
		List<List<String>> table = null;
		for (int i = 0; i < nNoOfSheets; i++) {
			CReadExcelFile xlsheet = new CReadExcelFile(filename);
			if ((table = xlsheet.LoadExcelWorkSheet(i)) != null) {
				String tmpStr = xlsheet.getSheetName().trim();
				if (tmpStr.substring(0, 2).equals("TC")) {
					tmpStr = tmpStr.substring(0, 2);
				}
				switch (tmpStr) {
					case "TestSuite":
						for (List<String> ts: table) {
							boolean runmode = false;
							if (String.valueOf(ts.get(2)).equalsIgnoreCase("Y"))
								runmode = true;
							testsuites.add(new CTestSuite(ts.get(0).toString(), ts.get(1).toString(), runmode, ts.get(3).toString()));
						}
						break;
					case "Keywords":
						for (List<String> ts: table) {
							keywords.add(new CKeywords(ts.get(0), ts.get(1)));
						}
						break;
					case "Locators":
						for (List<String> ts: table) {
							locators.add(new CLocators(ts.get(0), ts.get(1)));
						}
						break;
					case "TC":
						ArrayList<CTestCases> tcs = new ArrayList<CTestCases>();
						for (List<String> ts: table) {
							tcs.add(new CTestCases(ts.get(0), ts.get(1), ts.get(2), ts.get(3), ts.get(4), ts.get(5), ts.get(6), ts.get(7)));
						}
						testcases.put(xlsheet.getSheetName().trim(), tcs);
						break;
				}
			}
		}
		return;
	}
	
	public void UpdateTestEngineXLFile(String filename, String filepath) {
		CWriteExcelFile updateXLFile = new CWriteExcelFile(filename, filepath);
		updateXLFile.WriteResultsToExcelFile(testcases, testsuites);
	}
	
	public WebElement getLocatorType(String locatorType, String locatorValue) {
		switch (locatorType.toLowerCase().trim()) {
			case "id" :
				return getWebDriver().findElement(By.id(locatorValue));
			case "xpath" :
				return getWebDriver().findElement(By.xpath(locatorValue));
			case "cssselector" :
				return getWebDriver().findElement(By.cssSelector(locatorValue));
		}
		
		return null;
	}
	
	public List<CKeywords> getKeywords() {
		return keywords;
	}

	public List<CLocators> getLocators() {
		return locators;
	}

	public Map<String, ArrayList<CTestCases>> getTestcases() {
		return testcases;
	}

	public List<CTestSuite> getTestsuites() {
		return testsuites;
	}
	
	public void DBGPrintKeyWords() {
		for (CKeywords kw: getKeywords()) {
			System.out.println("Keyword: " + kw.getKeyword() + " " + kw.getDescription());
		}
	}
	
	public void DBGPrintTestSuite() {
		for (CTestSuite ts: getTestsuites()) {
			System.out.println("TestSuites: " + ts.getTestcase() + " " + ts.getDescription() + " " + ts.isRunmode() + " " + ts.getTestresult());
		}
	}
	
	public void DBGPrintLocators() {
		for (CLocators tl: getLocators()) {
			System.out.println("Locators: " + tl.getLocator() + " " + tl.getDescription());
		}
	}
	
	public void DBGPrintTestCases() {
		for (Map.Entry<String, ArrayList<CTestCases>> tcs: getTestcases().entrySet()) {
			System.out.println("Key: " + tcs.getKey());
			for (CTestCases tc: tcs.getValue()) {
				System.out.println(tc.getTcid() + " " + tc.getPageobject() + " " + tc.getTeststep() + " " + tc.getKeyword() + " " + tc.getLocatortype() + " " + tc.getLcoatorvalue() + " " + tc.getParameter() + " " + tc.getConditional());
			}			
		}
	}
}
