package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import testsuite.Log;

public class CReadExcelFile {
	private String filename;
	private String sheetname;
	private HSSFWorkbook workbook;
	List<List<String>> worksheet;
	
	public CReadExcelFile(String fn) {
		filename = fn;
		sheetname = null;
		File file = new File(filename);
		try {
			workbook = new HSSFWorkbook(new FileInputStream(file));
			worksheet = new ArrayList<List<String>>();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void CloseStream() {
		try {
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<List<String>> LoadExcelWorkSheet(int idx) {
		HSSFSheet sheet = workbook.getSheetAt(idx);
		sheetname = sheet.getSheetName();
		
		if (sheet.getLastRowNum() == 0) {
			CloseStream();
			return null;
		}
		
		int nRows = sheet.getLastRowNum();
		int nCols = sheet.getRow(0).getLastCellNum();
		Log.info("Loading TestEngine Data from XLSheet: " + sheetname.toString() + " to TestEngine Memory!");
		for (int i = 1; i <= nRows; i++) {
			List<String> rowData = new ArrayList<String>();
			for (int j = 0; j < nCols; j++) {
				rowData.add(String.valueOf(sheet.getRow(i).getCell(j)));
			}
			worksheet.add(rowData);
		}
		Log.info("Completed TestEngine Data Load from XLSheet: " + sheetname.toString() + " to TestEngine Memory!");
		CloseStream();
		return worksheet;
	}
	
	public final String getSheetName() { return sheetname; }
	
	public void DBGPrintListOFList() {
		for (List<String> list: worksheet) {
			System.out.println(list.toString());
			for (String s: list) {
				System.out.println(s);
			}
		}
	}
}


