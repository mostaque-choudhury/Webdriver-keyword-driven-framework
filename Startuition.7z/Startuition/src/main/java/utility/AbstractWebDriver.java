package utility;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import pagefactory.HomePage;
import testsuite.Log;

public class AbstractWebDriver {
	protected WebDriver driver = null;
	protected String driverName = null;
	protected HomePage onHomePage;
	
	public AbstractWebDriver(String driverName) {
		this.driverName = driverName;
		switch (driverName) {
		case "firefox" :
			driver = new FirefoxDriver();
			break;
		case "iexplorer" :
			driver = new InternetExplorerDriver();
			break;
		case "chrome" : 
			System.setProperty("webdriver.chrome.driver", "C:\\Selenium WebDriver Training\\chromedriver.exe");
			driver = new ChromeDriver();
			Log.info("Setting up chrome driver");
			break;
		}
	}
	
	public WebDriver getWebDriver() { return driver; }
	
	@Before
	public void setUp() {
		AbstractWebDriver wd = new AbstractWebDriver("chrome");
		if (wd.getWebDriver() == null) {
			System.out.println("Invalid Driver.");
			System.exit(-1);
		}
		else {
			onHomePage = new HomePage(driver);
		}
	}
	
	@After
	public void shutDown() {
		if (driver != null) {
			Log.info("Shuting down Webdriver: " + driverName);
			driver.close();
		}
	}
}
