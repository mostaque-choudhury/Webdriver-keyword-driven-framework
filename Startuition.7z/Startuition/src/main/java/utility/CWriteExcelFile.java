package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import testsuite.CTestCases;
import testsuite.CTestSuite;
import testsuite.Log;

public class CWriteExcelFile {
	private String filename;
	private String filepath;
	private FileOutputStream fos;
	private HSSFWorkbook wb = null;
	private HSSFSheet sheet;

	public CWriteExcelFile(String filename, String filepath) {
		this.filename = filename;
		this.filepath = filepath;

		try {
			fos = null;
			wb = new HSSFWorkbook(new FileInputStream(new File(filepath + filename)));
			sheet = wb.getSheetAt(0);
		} catch (FileNotFoundException ex) {

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public void WriteResultsToExcelFile(Map<String, ArrayList<CTestCases>> testcases, List<CTestSuite> testsuites) {
		// loop through test suite in memory and update test result field
		Iterator<Sheet> iter = wb.sheetIterator();
		while (iter.hasNext()) {
			HSSFSheet sh = (HSSFSheet) iter.next();
			if (sh.getSheetName().equals("TestSuite")) {
				for (CTestSuite ts : testsuites) {
					// update the TestSuite Sheet
					Cell cell = null;
					for (int i = 0; i < testsuites.size(); i++) {
						for (int j = 0; j < sheet.getRow(i).getLastCellNum(); j++) {
							if (sheet.getRow(i).getCell(j).getStringCellValue().equals(ts.getTestcase())) {
								if (ts.isRunmode()) {
									cell = sheet.getRow(i).getCell(sheet.getRow(i).getLastCellNum() - 1);
									cell.setCellValue(ts.getTestresult());
									// now Loop through test cases and update
									HSSFSheet tcSheet = wb.getSheet(ts.getTestcase());
									for (Entry<String, ArrayList<CTestCases>> tc : testcases.entrySet()) {
										if (tc.getKey().toString().equals(tcSheet.getSheetName())) {
											Iterator<Row> rowIter = tcSheet.rowIterator();
											rowIter.next();
											Cell tcCell = null;
											Iterator<CTestCases> tcIter = tc.getValue().iterator();
											while (rowIter.hasNext() && tcIter.hasNext()) {
												Row row = rowIter.next();
												CTestCases tcase = tcIter.next();
												Iterator<Cell> cellIter = row.cellIterator();
												while (cellIter.hasNext()) {
													tcCell = cellIter.next();
													String tmpValue = null;
													if (tcCell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
														tmpValue = String.valueOf(tcCell.getNumericCellValue());
													} else {
														tmpValue = String.valueOf(tcCell.getStringCellValue());
													} 
													if (tmpValue.equalsIgnoreCase("pending")) { 
														tcCell.setCellValue(
																tcase.getTeststepstatus());
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		String oFilename = "Result_" + filename;
		Log.info("\nLoading Run Status to TestEngine XL Output File: " + filepath + oFilename + "\n");
		try {
			fos = new FileOutputStream(new File(filepath + oFilename));
			wb.write(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
