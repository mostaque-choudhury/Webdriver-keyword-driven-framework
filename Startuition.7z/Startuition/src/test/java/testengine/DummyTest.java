package testengine;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import testsuite.Log;

public class DummyTest {
	CTestEngine testEngine;
		@Before
		public void setUp() {
			PropertyConfigurator.configure(System.getProperty("user.dir") + "/src/main/resources/log4j.properties");
			System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.Jdk14Logger");
			testEngine = new CTestEngine();
		}
		
		@Test
		public void runTest() {
			testEngine.RunTestCases();
		}
		
		@After
		public void shutDown() {
			Log.info("\n+++++++++++++++++++++++++\t\t\tShutting Down Webdriver\t\t\t+++++++++++++++++++++++++");
			testEngine.getCTEngineInit().getWebDriver().close();
		}
}
