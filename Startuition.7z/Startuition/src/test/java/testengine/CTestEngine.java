package testengine;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import testsuite.CTestCases;
import testsuite.CTestSuite;
import testsuite.Log;
import utility.CTestEngineInialise;

public class CTestEngine {
	protected CTestEngineInialise inialiseTE;
	
	public CTestEngine() {
		inialiseTE = new CTestEngineInialise("C:\\Selenium WebDriver Training\\Maven WD Project\\Startuition\\src\\main\\resources\\" + "TestEngine.xls");
		inialiseTE.LoadTestEngineToMemory();
	}
	
	public CTestEngineInialise getCTEngineInit() { return inialiseTE; }
	
	public void RunTestCases() {
		List<CTestSuite> testSuites = getCTEngineInit().getTestsuites();
		Map<String, ArrayList<CTestCases>> testCases = getCTEngineInit().getTestcases();
		
		// loop through each row in test suite in memory and run test based on runmode operandum
		Iterator<CTestSuite> iter = testSuites.iterator();
		while (iter.hasNext()) {
			CTestSuite testsuite = iter.next();
			if (!testsuite.isRunmode()) {
				continue;
			}
			else {
				// find the test case in the test case map...
				for (Map.Entry<String, ArrayList<CTestCases>> mtc: testCases.entrySet()) {
					if (mtc.getKey().equalsIgnoreCase(testsuite.getTestcase())) {
						// found one... so run it now!
						boolean bErr = false;
						Log.startTestCase(testsuite.getTestcase());
						List<CTestCases> testcase = mtc.getValue();
						Iterator<CTestCases> tc = testcase.iterator();
						while (tc.hasNext()) {
							CTestCases tcase = tc.next();
							WebElement element = null;
							switch (tcase.getKeyword().toLowerCase()) {
							case "navigate" :
								try {
									getCTEngineInit().getWebDriver().navigate().to(tcase.getParameter());
									tcase.setTeststepstatus("Passed");
									Log.info(tcase.getTeststep() + " | " + tcase.getParameter() + " | " + tcase.getTeststepstatus());
								} catch (Exception e) {
									tcase.setTeststepstatus("Failed");
									Log.error("Could not complete " + testsuite.getTestcase() + " | "  + " Step: " +  tcase.getTeststep() + " | " + "Could not navigate to " + tcase.getParameter() + " | " + tcase.getTeststepstatus());
								}
							break;
							case "click" :
								try {
									element = getCTEngineInit().getLocatorType(tcase.getLocatortype(), tcase.getLcoatorvalue());
									if (element != null) {
										element.click();
										tcase.setTeststepstatus("Passed");
										Log.info(tcase.getTeststep() + " | " + tcase.getLocatortype() + " | " + tcase.getLcoatorvalue() + " | " + tcase.getTeststepstatus());
									} 
								} catch(WebDriverException e) {
									bErr = true;
									tcase.setTeststepstatus("Failed");
									Log.error("Could not complete " + testsuite.getTestcase() + " | "  + " Step: " +  tcase.getTeststep() + " | " + "Could not find " + tcase.getLocatortype() + " | "  + tcase.getLcoatorvalue() + " | " + tcase.getTeststepstatus());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
									Log.info("\n\t\t\t\t\t\t\t\t\t\t*********WebDriver Error*********\t\t\t\t\t\t\t\t\t\t\n");
									Log.error(e.getMessage());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
								}
							break;
							case "sendkeys" :
								try {
									element = getCTEngineInit().getLocatorType(tcase.getLocatortype(), tcase.getLcoatorvalue());
									if (element != null) {
										if (tcase.getParameter() != null || tcase.getParameter() != "") {
											element.sendKeys(tcase.getParameter());
											tcase.setTeststepstatus("Passed");
											Log.info(tcase.getTeststep() + " | " + tcase.getLocatortype() + " | " + tcase.getLcoatorvalue() + " | " + tcase.getParameter() + " | " + tcase.getTeststepstatus());
										}
									}
								} catch(WebDriverException e) {
									bErr = true;
									tcase.setTeststepstatus("Failed");
									Log.error("Could not complete " + testsuite.getTestcase() + " | "  + " Step: " +  tcase.getTeststep() + " | " + "Could not find " + tcase.getLocatortype() + " | "  + tcase.getLcoatorvalue() + " | " + tcase.getTeststepstatus());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
									Log.info("\n\t\t\t\t\t\t\t\t\t\t*********WebDriver Error*********\t\t\t\t\t\t\t\t\t\t\n");
									Log.error(e.getMessage());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
								}
							break;
							case "waitforele" :
								try {
									WebDriverWait wait = new WebDriverWait(getCTEngineInit().getWebDriver(), (long) Double.parseDouble(tcase.getParameter()));
									switch (tcase.getLocatortype().toLowerCase()) {
									case "id" :
										wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(tcase.getLcoatorvalue())));
									break;
									case "xpath" :
										wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tcase.getLcoatorvalue())));
									break;
									case "cssselector" :
										wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(tcase.getLcoatorvalue())));
									break;
									}	
									tcase.setTeststepstatus("Passed");
									Log.info(tcase.getTeststep() + " | " + tcase.getLocatortype() + " | " + tcase.getLcoatorvalue() + " | " + tcase.getTeststepstatus());
								} catch (WebDriverException e) {
									bErr = true;
									tcase.setTeststepstatus("Failed");
									Log.error("Could not complete " + testsuite.getTestcase() + " | "  + " Step: " +  tcase.getTeststep() + " | " + "Could not find " + tcase.getLocatortype() + " | "  + tcase.getLcoatorvalue() + " | " + tcase.getTeststepstatus());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
									Log.info("\n\t\t\t\t\t\t\t\t\t\t*********WebDriver Error*********\t\t\t\t\t\t\t\t\t\t\n");
									Log.error(e.getMessage());
									Log.info("\n--------------------------------------------------------------------------------------------------------------------------------\n");
								}
							}
						}
						if (!bErr) {
							testsuite.setTestresult("PASSED");
							Log.info("++++++++++++++++++++++++++++++ Successfully Completed Running: " + testsuite.getTestcase() + " | " + testsuite.getTestresult() + " +++++++++++++++++++++++++++++++++++++++++");
						}
						else {
							testsuite.setTestresult("FAILED");
							Log.info("++++++++++++++++++++++++++++++ Unsuccessfully Completed Running: " + testsuite.getTestcase()  + " | " + testsuite.getTestresult() + " +++++++++++++++++++++++++++++++++++++++++");
						}
						
						Log.info("\n");
					}
				}
			}		
		}
		
		getCTEngineInit().UpdateTestEngineXLFile("TestEngine.xls", "C:\\Selenium WebDriver Training\\Maven WD Project\\Startuition\\src\\main\\resources\\");
		// inialiseTE.getWebDriver().close();
	}
}
